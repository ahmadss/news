package id.co.achmad.flutter_app_news

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
