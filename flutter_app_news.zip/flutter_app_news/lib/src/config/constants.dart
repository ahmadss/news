// App title
const String kAppTitle = 'News App';
