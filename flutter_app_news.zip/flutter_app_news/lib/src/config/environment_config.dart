class EnvironmentConfig {
  String newsApiKey = '6357577c409a4d5c8783324c8698f531';
}
