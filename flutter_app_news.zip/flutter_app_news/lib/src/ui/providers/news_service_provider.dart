import 'package:flutter_app_news/src/services/news_service.dart';
import 'package:dio/dio.dart';
import 'package:riverpod/riverpod.dart';

final newsServiceProvider = Provider<NewsService>((ref) {
  return NewsService(Dio());
});
