import 'package:flutter_app_news/src/config/environment_config.dart';
import 'package:riverpod/riverpod.dart';

final environmentConfigProvider = Provider<EnvironmentConfig>((ref) {
  return EnvironmentConfig();
});
