import 'package:flutter_app_news/src/config/environment_config.dart';
import 'package:flutter_app_news/src/models/article.dart';
import 'package:flutter_app_news/src/ui/providers/news_service_provider.dart';
import 'package:riverpod/riverpod.dart';

final _environmentConfig = EnvironmentConfig();

final newsFutureProvider =
    FutureProvider.autoDispose<List<Article>>((ref) async {
  ref.maintainState = true;
  final newsService = ref.read(newsServiceProvider);

  final articles = newsService.getArticles(
    path:
        'https://newsapi.org/v2/top-headlines?language=id&apiKey=${_environmentConfig.newsApiKey}',
  );
  return articles;
});
